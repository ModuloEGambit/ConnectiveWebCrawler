import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.util.*;

public class Connect {

    public Connect(List<String> list) throws IOException {
        //node = Jsoup.connect("https://en.wikipedia.org/wiki/Lead").get();
        for(String url:list){
            urlConnect(url);
        }


    }


    public void urlConnect(String url) throws IOException{
        Document newNode;
        newNode = Jsoup.connect(url).get();
        connectAndRetrieveRAW(newNode);
    }


    //Checks what String is inserted, then counts the frequency of each word
    private void frequencyWordCheck(String set) {
        Map<String, Integer> subArchive = new HashMap<>();

        for (String word : set.split(" ")) {
            if (subArchive.containsKey(word)) {
                subArchive.put(word, subArchive.get(word) + 1);

            } else {
                subArchive.put(word, 1);
            }

        }
        System.out.println(subArchive.toString());
        BinarySearch binSearch = new BinarySearch(subArchive);
    }

    //Changes document's content to String, while checking sites
    private void connectAndRetrieveRAW(Document doc){
        String nodeToText = doc.text();

        String appendSet = "" + doc.title() + "\n" +
                doc.location() + "\n" +
                nodeToText + "\n";

        System.out.println(appendSet);

        frequencyWordCheck(appendSet);
    }

}
