import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class BinarySearch {
    TreeMap<String, Integer> treeMap;
    Map<String,Integer> list;
    public BinarySearch(Map<String,Integer> list){
       treeMap = new TreeMap<>();

       this.list = new HashMap<>();
       this.list.putAll(list);

       loopOrganise(this.list);

       convertToHashMap();
    }

    private void loopOrganise(Map<String,Integer> listMap){
        Iterator it = listMap.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            treeMap.put((String) pair.getKey(), (Integer) pair.getValue());
            System.out.println(pair.getKey() + " = " + pair.getValue());
            it.remove();
        }

    }

    private void convertToHashMap(){
        this.list.clear();
        this.list.putAll(treeMap);

        for(Map.Entry<String,Integer> branch: list.entrySet()) {
            System.out.println(branch.getKey() + " = " + branch.getValue());


        }

    }

    private static void printAll(TreeMap<String, Integer> treeMap){
        for(Map.Entry<String,Integer> branch : treeMap.entrySet()){
            System.out.println(branch.getKey() + " = " + branch.getValue());
        }
        System.out.println();
    }
}
