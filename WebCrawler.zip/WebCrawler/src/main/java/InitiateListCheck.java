import java.io.*;

import java.util.ArrayList;
import java.util.List;

public class InitiateListCheck {
    public static void main(String[] args) throws IOException{
       new InitiateListCheck(args);
    }

    File file;
    List<String> list;
    Connect connect;
    public InitiateListCheck(String[] args) throws IOException {
        this.file = new File(args[0]);
        this.list = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(file));

        int indexCount = 0;
        String outputLine;

        System.out.println("Adding url from predefined list:");
        while((outputLine = br.readLine()) != null){
            list.add(outputLine);
            System.out.println("Added: " + outputLine);
        }

        connect = new Connect(this.list);


    }

}

