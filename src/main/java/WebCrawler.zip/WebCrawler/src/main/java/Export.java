
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.Number;
import jxl.write.biff.RowsExceededException;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Export {
    private static final String EXCEL_FILE_LOCATION = "output/webLinkTrends.xls";
    private static final String EXCEL_FILE_LOCATION_TRANSFER = "output/transfer.xls";
    private File file = new File(EXCEL_FILE_LOCATION);
    private WritableSheet RAW_wordCount;
    private WritableSheet RAW_webLinks;
    private WritableWorkbook transfer = null;
    private Workbook excel = null;
    private Map<String, String> harvestedLinkMap;
    private Map<String, Integer> wordCountLinkMap;

    public Export(Map<String, String> harvestedLinks, Map<String, Integer> wordCount) throws IOException, WriteException, BiffException {
        this.harvestedLinkMap = new HashMap<String, String>();
        this.harvestedLinkMap.putAll(harvestedLinks);

        this.wordCountLinkMap = new HashMap<String, Integer>();
        this.wordCountLinkMap.putAll(wordCount);


        excel = Workbook.getWorkbook(file);
        transfer = Workbook.createWorkbook(new File(EXCEL_FILE_LOCATION_TRANSFER), excel);

        writeRAWwebLinks();
        writeRAWWordCount();

        transfer.close();
    }


    private void writeRAWWordCount() throws WriteException, IOException {
        RAW_wordCount = transfer.createSheet("RAW_WordCount", 1);

        Label label = new Label(0, 0, "UNIQ_Node");
        RAW_wordCount.addCell(label);

        label = new Label(1, 0, "Word");
        RAW_wordCount.addCell(label);

        label = new Label(2, 0, "Count");
        RAW_wordCount.addCell(label);

        populateWordCountRAW();
    }

    private void populateWordCountRAW() throws WriteException, IOException {
        int cellROneCounter_Node = 0, cellRTwoCounter_Key = 0,cellRThreeCounter_Value = 0;
        final int ADD_ONE_FOR_CONTENTCELL = 1, KEY_COL = 2, VALUE_COL = 1, UNIQ_COL = 0, MAXROWS = 65536 - 25;
        int maxMemory = (int) Runtime.getRuntime().maxMemory();
        Iterator it = wordCountLinkMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            try{
            //Adds a unique number to the cell
            Number number = new Number(UNIQ_COL, cellROneCounter_Node++ + ADD_ONE_FOR_CONTENTCELL, cellROneCounter_Node);
            RAW_wordCount.addCell(number);

            //Adds the word - Word to the cell
            Label label = new Label(VALUE_COL, cellRTwoCounter_Key + ADD_ONE_FOR_CONTENTCELL, pair.getValue().toString());
            RAW_wordCount.addCell(label);

            //Adds the value - Count to the cell
            label = new Label(KEY_COL,cellRThreeCounter_Value + ADD_ONE_FOR_CONTENTCELL, pair.getKey().toString());
            RAW_wordCount.addCell(label);

            if((Runtime.getRuntime().totalMemory() > (maxMemory / 1.5) || RAW_wordCount.getRows() > MAXROWS)){
                if(RAW_wordCount.getRows() > MAXROWS){
                    RAW_wordCount = transfer.createSheet("RAW_WordCount" + excel.getNumberOfSheets() + 1, excel.getNumberOfSheets() + 1);
                }
                System.out.println("Releasing memory : writing to sheet... : " );
                transfer.write();


            }
        }catch(RowsExceededException e){
            break;
        }
        }
    }



    private void writeRAWwebLinks() throws WriteException, IOException {
        RAW_webLinks = transfer.createSheet("RAW_WebLinks", 0);

        Label label = new Label(0,0,"UNIQ_Node");
        RAW_webLinks.addCell(label);

        label = new Label(1,0, "Title");
        RAW_webLinks.addCell(label);

        label = new Label(2,0, "URL");
        RAW_webLinks.addCell(label);

        populateWebLinkRAW();
    }

    private void populateWebLinkRAW() throws WriteException {
        int cellROneCounter_Node = 0, cellRTwoCounter_Key = 0,cellRThreeCounter_Value = 0;
        final int ADD_ONE_FOR_CONTENTCELL = 1, KEY_COL = 2, VALUE_COL = 1, UNIQ_COL = 0;

        Iterator it = harvestedLinkMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            try {
                //Adds a unique number to the cell
                Number number = new Number(UNIQ_COL, cellROneCounter_Node++ + ADD_ONE_FOR_CONTENTCELL, cellROneCounter_Node);
                RAW_webLinks.addCell(number);

                //Adds the value - Title to the cell
                Label label = new Label(VALUE_COL, cellRThreeCounter_Value + ADD_ONE_FOR_CONTENTCELL, pair.getValue().toString());
                RAW_webLinks.addCell(label);

                //Adds the key - weblink to the cell
                label = new Label(KEY_COL, cellRTwoCounter_Key + ADD_ONE_FOR_CONTENTCELL, pair.getKey().toString());
                RAW_webLinks.addCell(label);
            }catch(RowsExceededException e){
                break;
            }
    }
    }
}
