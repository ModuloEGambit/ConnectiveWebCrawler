import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.*;

public class Connect {
    Export export;
    Map<String,Integer> wordCountList;
    Map<String,String> urlHarvestedList;
    public Connect(List<String> list) throws IOException, WriteException, BiffException {
        wordCountList = new HashMap<>();
        urlHarvestedList = new HashMap<>();
        //node = Jsoup.connect("https://en.wikipedia.org/wiki/Lead").get();
        for(String url:list){
            urlConnect(url);
        }


        Export export = new Export(urlHarvestedList, wordCountList);
    }

    public void urlConnect(String url) throws IOException{
        Document newNode;
        newNode = Jsoup.connect(url).get();
        harvestURLLinksFromIndexPage(newNode);
        repeatedHarvesterWordCount();
        //connectAndRetrieveTextFromIndexPage(newNode);
    }

    //Looks into the harvestList of URLS and does a frequency word check, adding to the list
    private void repeatedHarvesterWordCount() throws IOException {
        Iterator it = urlHarvestedList.entrySet().iterator();
        Document doc;
        int counter = 0, maxSize = urlHarvestedList.size();
        String url, textOfWebpage;
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            url = (String) pair.getKey();
            System.out.println("Analysing : " + counter++ + " of "  + maxSize + " - " + pair.getKey() + " : " + pair.getValue() );
            try{
                doc = Jsoup.connect(url).get();
                textOfWebpage = doc.text();
                wordCountList.putAll(frequencyWordCheck(textOfWebpage));
            } catch(Exception e){
                e.getMessage();
            }
        }
    }
    //Checks what String is inserted, then counts the frequency of each word
    private Map<String,Integer> frequencyWordCheck(String set) {
        Map<String, Integer> subArchive = new HashMap<>();

        for (String word : set.split(" ")) {
            if (subArchive.containsKey(word)) {
                subArchive.put(word, subArchive.get(word) + 1);

            } else {
                subArchive.put(word, 1);
            }

        }
        return subArchive;
    }


    private void harvestURLLinksFromIndexPage(Document doc) {
        System.out.println("Harvesting Test");
        Elements wholeURLListRAW = doc.select("a[href]");
        String title, partialURL, wholeURL = "", origURL;
        String[] seperatedDepth;


        for (Element partial : wholeURLListRAW) {
            partialURL = partial.attr("href");
            System.out.println(partialURL);

            origURL = doc.location();
            System.out.println(origURL);
            seperatedDepth = origURL.split("/");
            origURL = constructOrigUrl(seperatedDepth);


            if (!(partialURL.startsWith("http"))) {
                if (isStartingWithBackslash(partialURL)) {
                    partialURL = partialURL.replaceFirst("/", "");
                }
                wholeURL = origURL + partialURL;
                System.out.println("Whole URL : " + wholeURL);
            }
            if (!(isDuplicateLink(wholeURL))) {
                urlHarvestedList.put(wholeURL, partial.text());
            }
        }

        printAllHarvestedList();
    }


    private String constructOrigUrl(String[] depthOfBackslash){
        StringBuilder builder = new StringBuilder();
        System.out.println("    Depth of URL -- " + depthOfBackslash.length);
        for(int depth = 0; depth < 3; depth++){
            System.out.println(depthOfBackslash[depth]);

            builder.append(depthOfBackslash[depth]);
            builder.append('/');
        }
        System.out.println("Constructed new URL : " + builder.toString());
        return builder.toString();
    }


    public boolean isStartingWithBackslash(String url){
        return url.startsWith("/");
    }

    public boolean isEndingWithBackslash(String url){
        return url.endsWith("/");
    }

    private void printAllHarvestedList() {
        Iterator it = urlHarvestedList.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            System.out.println("Key: " + pair.getKey() + " : " + pair.getValue());
        }
    }


    private boolean isDuplicateLink(String urlLink){
        Iterator it = urlHarvestedList.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            if (urlLink.equals(pair.getValue())) {
                return true;
            }
        }
        return false;
    }

    private void checkDuplicateLinkInHashMap(String url){

    }
    //Changes document's content to String, while checking sites
    private void connectAndRetrieveTextFromIndexPage(Document doc){
        String nodeToText = doc.text();

        String appendSet = "" + doc.title() + "\n" +
                doc.location() + "\n" +
                nodeToText + "\n";

        System.out.println(appendSet);

        frequencyWordCheck(appendSet);
    }

}
